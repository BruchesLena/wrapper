package model;

import java.util.List;

public interface DataSet<T> {

	List<T> getData();
}
