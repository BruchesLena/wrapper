package model;

public class BatchNormalization extends Layer {
	
	public String toString() {
		return "Layer=BatchNormalization";
	}
	
}
