package model;

public class Flatten extends Layer {

	public String toString() {
		return "Layer=Flatten";
	}
}
