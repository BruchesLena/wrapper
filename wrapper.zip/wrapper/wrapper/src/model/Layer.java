package model;

public abstract class Layer {
	int inputDim;
	int neurons;
	String function;
	
	public String toString() {
		return null;
	}
}
