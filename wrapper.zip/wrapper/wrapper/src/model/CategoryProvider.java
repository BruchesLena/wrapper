package model;

public interface CategoryProvider<T> {

	public int getCategory(T data);
}
